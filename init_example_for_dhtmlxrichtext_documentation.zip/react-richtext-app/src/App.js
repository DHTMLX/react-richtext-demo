import React, { Component } from 'react';
import RichText from './components/RichText';

class App extends Component {
  render() {
    return (
        <div>
          <RichText />
        </div>
    );
  }
}

export default App;
