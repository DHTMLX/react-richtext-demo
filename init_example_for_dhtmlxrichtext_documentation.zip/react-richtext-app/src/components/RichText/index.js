import RichText from './RichText';
import './RichText.css';

export default RichText;
